# cursor

Personal workspace for Google CAD interview prep and related Cursor chats.

**This repository is public.** Files include personal career, pay, and contact details. Switch the repo to private if that should not be public.

- [docs/interview/google-cad-interview-cheatsheet.md](docs/interview/google-cad-interview-cheatsheet.md) — full HM/deep-dive dump
- [CONTINUE.md](CONTINUE.md) — where to pick up
- [chats/](chats/README.md) — imported conversations
