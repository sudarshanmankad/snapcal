# Doug — speak these (mock corrections only)

No grades. Pause, restate both halves, then say it.

---

## About me (~70s)

I’m a Staff Applications Engineer at Synopsys in functional verification methodology — mainly VCS, Verdi, and VC Z01X — with 9+ years as the primary technical interface for tier-1 accounts like Intel, NXP, and ARM. I own eval, POC, and large-scale deployment of verification flows, and I work day to day with DV and CAD engineers on simulation and debug methodology, adoption, automation, and escalations that can put tapeout at risk.

A few examples: multithreaded simulation at Intel Graphics with about 2× regression TAT; VC Z01X at NXP through tapeout on multiple IPs; and worldwide technical lead for Intel’s fault-grading program.

What draws me to Google is the vertical integration — silicon, systems, and AI workloads together, especially TPU. At Synopsys I help customers get to tapeout, but I’m not inside the chip team owning the outcome. I want that same deploy-and-standardize work inside Google, supporting TPU and AI silicon DV.

---

## Why Google / why now (~35s)

What draws me to Google is the vertical integration — silicon, systems, and workloads together, especially TPU and AI — so CAD methodology can actually move tapeout end to end. At Synopsys I’ve helped a lot of customers get to tapeout, but from the outside. I want to be inside the chip team, owning the outcome.

A lot of what I do maps: DV and CAD, deploy, escalate, drive adoption. I don’t see it as starting from zero. What’s different — and harder — is going deep on one product, building trust as an internal partner instead of a vendor, and being measured by whether Google’s DV throughput and tapeouts actually improve. That’s the stretch I want.

---

## MT sim STAR (~90s)

Intel Graphics already had a lean compile and sim setup, and they still needed about 2× regression TAT. I owned the VCS multithreaded-sim eval and deploy with their DV and CAD.

Diagnostics showed the design would parallelize. We POC’d a couple of designs, got strong multi-core numbers, then found MT-hostile code — delayed NBAs, always blocks with `#` delays, DPI tracking too much data. We partnered with DV to recode those, published the results, and only then ran a 600+ test qualification. Tool crashes and mismatches got reproduced, escalated, and fixed across builds. We did not make MT the default until it was stable. POC showed 5–8× on 16 cores; production is about 2× on 4 cores.

That IP is deployed, the same playbook is on other IPs, and SoCs are in flight. With 2× TAT the team gets more debug cycles and more tests, and they still hit tapeout.

---

## ST default + tool vs RTL vs limitation (~40s)

Single-thread stayed the production default. MT was a parallel eval path. We grew the MT slice, quarantined fails, and only flipped the default when it was stable — tapeout was not the experiment.

On a fail I compare the same seed ST vs MT. If ST is clean and MT crashes or mismatches, I minimize the test. Stack in the simulator → tool, escalate a reducible case. DPI-C in the stack → debug the C, but it can still be the tool. Mismatch → check RTL intent; we caught real races and partnered with DV/CAD to check in fixes. If it only shows under MT and the RTL is legal, that’s a limitation — bound it, keep ST, don’t make it the standard.

---

## Workaround vs right methodology (~25s)

If we’re near tapeout, the timeline wins. Ship a controlled workaround — document it, limit the scope, keep the production flow moving. I don’t drop root cause. I own getting the real fix in before the next project or the next version, so the workaround doesn’t become the standard. Same pattern on MT: ST stayed default, we quarantined fails, and we only made MT standard after the crashes were actually fixed.

---

## `=` vs `<=` (~25s)

If you model a flop with blocking `=` in `always @(posedge clk)`, Q updates immediately in the active region. Another process on the same edge may see the old D or the new D depending on execution order — that’s a simulation race, not metastability. It can change across simulators, versions, or switches. Non-blocking `<=` samples the pre-clock value and updates in the NBA region, so the flops move together. That’s the flop model. We catch it with lint/review, and in debug when a mismatch is order- or version-dependent.

---

## X-prop top 3 + first X (~25s)

Top three: missing or incomplete flop reset; multi-driver; glitchy or transitional control on a conditional. Those are where I start. There are others — off domains, races — but those three first.

I don’t chase every downstream X. Hypothesis, then find the first X. XRCA is the method I deployed for that — trace to the source, not the storm. That’s how we cut X-prop debug cycles more than 50%.

---

## UVM hang (~20s)

Clock first — is it still toggling? Then which phase, and who still has an objection — objection trace, not a guess. Then TB: sequence started, agent active, `item_done` / seq-driver handshake. A type mismatch on seq set vs get in the driver/agent can hang here. If the TB is clean, DUT deadlock. Tool last, after I can show ST vs a reducible case. I don’t write UVM TBs every day, but I debug hangs with DV constantly — I separate TB, DUT, methodology, and tool quickly.

---

## uvm_config_db (~15s)

Four things have to match: type, field name, hierarchical path, and timing. Type is the VIF parameterization. Name is the string. Path is context plus instance so the getter can see it. Timing is the usual miss — `get` in `build` before anyone `set`, or `set` after build. I debug with topology, get-status, and config tracing.

---

## Hard-to-hit vs UNR (~25s)

Hard-to-hit is legal but rare — an FSM state that can happen, just not in random. That’s directed tests or tighter constraints. Unreachable will never happen in this RTL — don’t keep throwing stimulus at it. Exclude it or fix the model or the RTL. That’s what VCS UNR is for: automated unreachability so we close coverage without fake stimulus. Two examples: a branch compiled out by a parameter, and an FSM arc that the encoding can never take.

---

## GLS X open (~25s)

RTL X-prop I start with reset, multi-driver, glitchy control, and I chase the first X — XRCA, not the storm. GLS is later and slower. There I also ask: is this a functional X or a timing-check X from SDF? Setup/hold can put X on Q. That’s a timing model, not metastability unless we’re in CDC. CAD job is the flow — zero-delay vs SDF, checks, TAT — and a debug method that doesn’t burn the tapeout regression.

---

## GLS: checks off, two weeks out (~30s)

First split: is zero-delay GLS clean? I want that data in the flow before SDF GLS. If zero-delay is dirty, this is functional X — reset, multi-driver, glitchy control, maybe reset/clock after CTS or contention. Don’t chase SDF yet. If zero-delay is clean and SDF GLS is an X storm, it’s timing: setup/hold putting X on Q, or bad/partial SDF. I still chase the first X, not every downstream X.

I do not turn timing checks off globally two weeks from tapeout. If one path is a known pessimistic check burning the line, we can bound that check — documented, limited, zero-delay stays green — and I own the real STA/fix. Tapeout gets a controlled workaround, not a silent new standard.

---

## 0-delay dirty, RTL xprop clean (~30s)

First I make the compare fair: was RTL xprop even on, and was it optimistic or pessimistic, same test and seed? If RTL was optimistic or xprop-off, GLS can show X that RTL hid. If RTL pessimistic xprop was clean, I look at GLS-only sources: disconnected or floating nets, wrong std-cell or lib config, reset/clock connectivity after CTS, contention, isolation.

I still want the first X, not the storm. If X shows at 20ps in a 1000ps run, I don’t rerun the whole thing. I rerun to that time — waves on that cone — and trace the source. That’s how you debug a huge netlist without burning TAT.

---

## X-optimism vs pessimism

Pessimism: control is X → output X even if both data inputs match.

Optimism: control is X → output X only if the data inputs differ; if they match, it passes that value and can hide an X bug.

Optimism hides bugs. Pessimism can X-storm. That’s why I ask which merge RTL ran.

---

## UPF isolation (~20s)

If a domain is off and X is storming the live logic, I first check isolation — is the ISO on the right boundary, is the isolation signal on, is the clamp what we intended. Corruption inside the off domain can be expected. The bug is X getting out. I’m the methodology partner on the sim/UPF flow, not the UPF architect.

---

## Off-domain X + ISO vs retention (~20s)

X inside an off domain is often expected corruption — that’s acceptable. It’s a flow bug when that X shows up on the live side of the boundary: isolation missing, on the wrong element, enable off, or wrong clamp. It’s also a bug if we expected retention and the flop went X instead of saved state.

Isolation clamps a crossing signal to 0 or 1 per policy so the on-domain doesn’t see corruption. Retention saves specified registers across power-down and restores them. ISO protects neighbors; retention protects our state.

---

## SVA + fail storm (~25s)

Immediate is like an `if` in the active region. Concurrent is clocked — sample in the preponed region, evaluate later — typically `|->` with `disable iff` reset. Assert must hold. Assume constrains the environment, especially formal. Cover records that a behavior happened.

Fail storm: first reset and `disable iff`, then sampling and X on the sampled signals, then whether the property is even right. I don’t chase every fail — same first-cause idea as X-prop. I care about assertion cost in regression, not writing the spec.

---

## Constraints vs UNR (~25s)

If `randomize()` errors on conflicting constraints, that’s a solver fail — no solution. I debug the conflict it points at and fix the TB. That’s not UNR.

If sim runs but coverage is short, it may just be over-narrow or hard-to-hit — legal, just rare or biased. Then I relax, use `dist` for spread, or add directed tests. `solve before` is variable order when one constraint depends on another.

Unreachable is different: it can never happen in this RTL. Don’t throw more random at it — UNR, exclude, or fix the model. Three different problems.

---

## Ask Doug

What does success look like in the first 6–12 months for this CAD role — on the team, not just in the JD?

Is this a backfill or a new seat? I ask because it changes what the first year looks like — inherit and stabilize a flow vs stand something up.

How big is the CAD team, and how is it spread across sites? How do you pair with TPU DV day to day?

For the two deep-dive rounds, what should I emphasize — coding, methodology, or debug scenarios? If there’s coding, is it a shared doc or an IDE, and closer to SV/DV or general scripting?

## Close

This maps closely to what I do with DV and CAD at tier-1 accounts. I’m interested in continuing to the deeper technical rounds if you want to move forward.

## If he presses comp

I’m targeting upper half of the posted band plus equity. Happy to do details with the recruiter.
