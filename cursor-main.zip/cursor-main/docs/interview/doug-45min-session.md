# Doug HM — 45-minute session

Live call shape (do not code on this call):

| Min | Block | What Doug is testing |
|-----|--------|----------------------|
| 0–5 | Intros / about me | Can you sound like CAD methodology, not a ticket AE or a TB author |
| 5–15 | Resume dig | Ownership, metrics, DV+CAD partnership, eval→deploy |
| 15–35 | Methodology / scenarios | STAR + SV/UVM probes; tapeout-timeline judgment |
| 35–45 | Your questions + close | Senior curiosity; ready for deep dives |

## Prep rules (on every answer)

- Say **automation**. Do not volunteer Python/Tcl.
- Tools: **VCS, Verdi, VC Z01X**. SG FA only if asked.
- Partner **DV and CAD**. No DFT in intro. No “CAD–DV boundary.”
- Tradeoffs = **tapeout / project timeline**.
- Metastability ≠ X and ≠ `=` / `<=` races.
- No ChipAgents pitch.

## Drill order (this prep)

1. About me (~70 sec) — from memory
2. Why Google / why now (ownership line)
3. Story A or B (global fault-grading **or** MT sim) — 2 min STAR
4. Workaround vs right methodology
5. Tech traps: `=`/`<=`, X-prop top 3, UVM hang, config_db
6. Your 4 questions + close

## Glance card

**Spine:** Staff AE · VCS/Verdi/Z01X · tier-1 · DV+CAD · deploy/automate/escalate · vertical integration / influence tapeout

**Stories:** global fault-grading lead · MT sim ~2× TAT · XRCA >50% · Z01X tapeout

**Ask:** success 6–12 mo · biggest pain · support vs projects · deep-dive format · Senior bar

**Close:** Ready for deep dives

## Attempt 1 — about me (spoken)

**Grade: B+ / hire-credible.** Job is right. Close is missing.

Landed: Staff AE; VCS/Verdi; DV+CAD; eval/POC/deploy; automation; escalations vs tapeout; MT ~2× TAT; NXP Z01X tapeout; UNR; global fault-grading.

Fixes:
- Say **VC Z01X**, not “VCZOIX”
- Name **9+ years**
- Three highlights, not five. Keep MT 2×, global fault-grading, NXP tapeout. Park UNR/gfx-lead for the dig.
- Do **not** end on Intel. End on Google: vendor vs inside, vertical integration, influence tapeout
- Optional if time: XRCA >50% X-prop debug

**70-sec target (their words, tightened):**

> I’m a Staff Applications Engineer at Synopsys in functional verification methodology — mainly VCS, Verdi, and VC Z01X — with 9+ years as the primary technical interface for tier-1 accounts like Intel, NXP, and ARM. I own eval, POC, and large-scale deployment of verification flows, and I work day to day with DV and CAD engineers on simulation and debug methodology, adoption, automation, and escalations that can put tapeout at risk.
>
> A few examples: multithreaded simulation at Intel Graphics with about 2× regression TAT; VC Z01X at NXP through tapeout on multiple IPs; and worldwide technical lead for Intel’s fault-grading program.
>
> What draws me to Google is the vertical integration — silicon, systems, and AI workloads together, especially TPU. At Synopsys I help customers get to tapeout, but I’m not inside the chip team owning the outcome. I want that same deploy-and-standardize work inside Google, supporting TPU and AI silicon DV.

Next drill: why Google / why now (ownership line), then MT or global-lead STAR.

## Attempt 2 — MT sim story (spoken)

**Grade: Strong facts, B narrative.** Doug would believe you. He would still ask how you protected tapeout.

Landed: TAT bottleneck; already-lean compile/sim; diagnostics → parallelizable; POC; recode MT-hostile RTL/DPI (`#` delays, delayed NBAs, DPI tracking too much); 600+ tests; tool bugs + builds; playbook to other IPs/SoC; **2× on 4 cores** → more debug / more tests / tapeout.

Fixes:
- Don’t lecture “every DV team’s bottleneck is TAT.” Start at Intel Graphics.
- Name **you** + **DV and CAD**. Eval → POC → qualify → deploy.
- Add the two numbers: **5–8× on 16 cores** (POC), production **~2× on 4 cores**. Don’t sell 16-core as the landed result.
- Say **VCS** multithreaded sim.
- Frame recode as **partnering with DV**, not “I rewrote their design.”
- Missing CAD judgment: **ST stays green**; quarantine fails; flip default only when stable.

**~90-sec STAR (speak this):**

> Intel Graphics already had a lean compile and sim setup, and they still needed about 2× regression TAT. I owned the VCS multithreaded-sim eval and deploy with their DV and CAD.
>
> Diagnostics showed the design would parallelize. We POC’d a couple of designs, got strong multi-core numbers, then found MT-hostile code — delayed NBAs, always blocks with `#` delays, DPI tracking too much data. We partnered with DV to recode those, published the results, and only then ran a 600+ test qualification. Tool crashes and mismatches got reproduced, escalated, and fixed across builds. We did not make MT the default until it was stable. POC showed 5–8× on 16 cores; production is about 2× on 4 cores.
>
> That IP is deployed, the same playbook is on other IPs, and SoCs are in flight. With 2× TAT the team gets more debug cycles and more tests, and they still hit tapeout.

Still open: why Google / ownership line.

## Attempt 3 — why Google (spoken)

**Grade: B.** Right idea (inside vs outside). Missing the stretch.

Landed: vertical integration; CAD impact end to end; Synopsys helped tapeouts from outside; want inside.

Fixes:
- “Load” → **workloads**. “Unclose” → **up close**.
- Name **TPU / AI silicon**, not only “hyperscaler.”
- Don’t stop at “I’d love to make an impact.” Add **why now**: same muscles, different ownership.
- What’s harder: one product’s priorities; internal partner not vendor; measured by **Google’s** tapeout and DV throughput.
- Avoid: “no big transition / I’m already doing this job.”

**~35-sec target:**

> What draws me to Google is the vertical integration — silicon, systems, and workloads together, especially TPU and AI — so CAD methodology can actually move tapeout end to end. At Synopsys I’ve helped a lot of customers get to tapeout, but from the outside. I want to be inside the chip team, owning the outcome.
>
> A lot of what I do maps: DV and CAD, deploy, escalate, drive adoption. I don’t see it as starting from zero. What’s different — and harder — is going deep on one product, building trust as an internal partner instead of a vendor, and being measured by whether Google’s DV throughput and tapeouts actually improve. That’s the stretch I want.

## Attempt 4 — ST default + MT triage (spoken)

**Grade: A- on schedule. B+ on triage.** Flip-default-last is now clear. Classification still needs ST vs MT.

Landed: ST stays production until MT is stable; MT is a parallel eval path; tool stacks vs DPI-C; mismatches can be races or tool; recoded races with DV/CAD. Did **not** say metastability.

Fixes:
- Add **same seed, ST vs MT**. ST pass / MT fail is the first CAD split.
- **Minimize** before escalating (smallest test, same plusargs/snapshot).
- Third bucket: **limitation** — bound it, don’t call it a bug, don’t make it the default.
- Close on classify → recode / escalate / bound — not only “I read the RTL.”

**~40-sec target:**

> Single-thread stayed the production default. MT was a parallel eval path. We grew the MT slice, quarantined fails, and only flipped the default when it was stable — tapeout was not the experiment.
>
> On a fail I compare the same seed ST vs MT. If ST is clean and MT crashes or mismatches, I minimize the test. Stack in the simulator → tool, escalate a reducible case. DPI-C in the stack → debug the C, but it can still be the tool. Mismatch → check RTL intent; we caught real races and partnered with DV/CAD to check in fixes. If it only shows under MT and the RTL is legal, that’s a limitation — bound it, keep ST, don’t make it the standard.

## Attempt 5 — workaround vs right methodology (spoken)

**Grade: B+.** Philosophy is right. Too thin for Doug.

Landed: tapeout near → ship workaround; replace before next project/version; **you own** the real fix.

Fixes:
- Say **controlled**: document, limit scope, don’t put it in the default flow.
- Don’t silently normalize.
- One example from MT: ST stays production; quarantine the MT fail; file the crash; land the tool/RTL fix; only then flip default.

**~25-sec target:**

> If we’re near tapeout, the timeline wins. Ship a controlled workaround — document it, limit the scope, keep the production flow moving. I don’t drop root cause. I own getting the real fix in before the next project or the next version, so the workaround doesn’t become the standard. Same pattern on MT: ST stayed default, we quarantined fails, and we only made MT standard after the crashes were actually fixed.

## Attempt 6 — `=` vs `<=` in clocked logic (spoken)

**Grade: A-.** Race, not metastability. That’s the trap. Last sentence about the clock is the weak part.

Landed: `=` on flops → Q can see old or new D; expected flop samples old/stable; **race**; can move across simulators/versions/switches; use `<=`.

Fixes:
- Say **why**: `=` updates in the **active** region immediately; other `always @(posedge clk)` blocks may see old or new depending on process order.
- `<=` samples now, updates in **NBA**, so flops on that clock move together on pre-clock values.
- CAD catch: lint/review; mismatch that moves with seed/order/version.
- Don’t lecture TB clock-gen unless asked. If you do: clock edge in active region, flop `<=` updates in NBA — not “the clock samples.”

**~25-sec target:**

> If you model a flop with blocking `=` in `always @(posedge clk)`, Q updates immediately in the active region. Another process on the same edge may see the old D or the new D depending on execution order — that’s a simulation race, not metastability. It can change across simulators, versions, or switches. Non-blocking `<=` samples the pre-clock value and updates in the NBA region, so the flops move together. That’s the flop model. We catch it with lint/review, and in debug when a mismatch is order- or version-dependent.

## Attempt 7 — X-prop top 3 (spoken)

**Grade: A- on sources. Incomplete on debug.** Top 3 match the locked frame. You did not answer first-X vs downstream X.

Landed: flop **reset**; **multi-driver**; **glitches on conditional/control**. Not metastability.

Missing: hypothesis → find the **first X**; **XRCA** (your >50% story); don’t chase every downstream X. Also-have if probed: low-power off domains, exposed races.

**~25-sec complete answer:**

> Top three: missing or incomplete flop reset; multi-driver; glitchy or transitional control on a conditional. Those are where I start. There are others — off domains, races — but those three first.
>
> I don’t chase every downstream X. Hypothesis, then find the first X. XRCA is the method I deployed for that — trace to the source, not the storm. That’s how we cut X-prop debug cycles more than 50%.

## Attempt 8 — UVM hang (spoken)

**Grade: B-.** Right last buckets (TB → DUT → tool). **Wrong order.** You skipped clock, and you opened with a specific seq type-mismatch instead of the checklist.

Landed: phase; which TB component; objections raise/drop; then DUT; tool last. Seq set vs driver/agent get is a real hang — park it under TB/config, not first.

Locked order: **clock → phase → objections → TB wait/seq/`item_done` → DUT deadlock → tool.**

Also-have: drain, phase timeout, heartbeat, forever loops in monitor/scoreboard. Objection **trace** / who has not dropped.

**~20-sec target:**

> Clock first — is it still toggling? Then which phase, and who still has an objection — objection trace, not a guess. Then TB: sequence started, agent active, `item_done` / seq-driver handshake. A type mismatch on seq set vs get in the driver/agent can hang here. If the TB is clean, DUT deadlock. Tool last, after I can show ST vs a reducible case. I don’t write UVM TBs every day, but I debug hangs with DV constantly — I separate TB, DUT, methodology, and tool quickly.

## Attempt 9 — uvm_config_db VIF get fails (spoken)

**Grade: B+.** Pieces are there. “Where to save” is not one of the four. Timing is right.

Locked four: **type + name + path + timing.**

- **Type** `#(T)` — the VIF type (or config object type)
- **Name** — field string (`"vif"`)
- **Path** — context + instance (`this`, `"*.agent"`) so the getter is in scope
- **Timing** — **set before get**; usual miss is set after the child’s `build` already `get`s

“Where to save” is just the `get` output argument. Debug if probed: topology print, get status, config tracing.

**~15-sec target:**

> Four things have to match: type, field name, hierarchical path, and timing. Type is the VIF parameterization. Name is the string. Path is context plus instance so the getter can see it. Timing is the usual miss — `get` in `build` before anyone `set`, or `set` after build. I debug with topology, get-status, and config tracing.

## Attempt 10 — hard-to-hit vs unreachable / UNR (spoken)

**Grade: B.** Distinction is right. You skipped what you **do**, **UNR**, and **two unreachable examples**.

Landed: hard-to-hit = still legal, directed/corners can hit; unreachable = never in the RTL’s life.

Fixes:
- Hard-to-hit → directed tests / constraints. Don’t call UNR.
- Unreachable → don’t thrash stimulus. Exclude, or fix the cover model / RTL. That’s **VCS UNR**.
- Two examples (pick these): (1) branch dead because of a **parameter**; (2) **FSM arc** that cannot occur given the encoding; optional: contradictory cover bins, dead else/default on a proven one-hot.

**~25-sec target:**

> Hard-to-hit is legal but rare — an FSM state that can happen, just not in random. That’s directed tests or tighter constraints. Unreachable will never happen in this RTL — don’t keep throwing stimulus at it. Exclude it or fix the model or the RTL. That’s what VCS UNR is for: automated unreachability so we close coverage without fake stimulus. Two examples: a branch compiled out by a parameter, and an FSM arc that the encoding can never take.

## Extra drill — X-prop + GLS

Pocket: [`xprop-gls-pocket.md`](xprop-gls-pocket.md)

RTL top 3 stay locked. GLS adds timing-check X, SDF annotation, gate pessimism. Not metastability by default.

**Status:** Extra GLS/UPF drill paused (user: move on). Locked: 0-delay vs SDF; first X + short rerun; optimism hides bugs; ISO vs retention; X inside off-PD often OK, X on live boundary is the bug.

**Next:** Candidate’s 4 questions + close.

**Inserted:** SVA + constraints drill before questions. Pocket: [`sva-constraints-pocket.md`](sva-constraints-pocket.md)

## Overall scorecard (questions skipped)

**Call verdict: hire-credible CAD HM. Lean B+.** Doug would likely send you to deep dives if intro + MT + ST-stays-default land clean. You are not failing a UVM-author bar — that isn’t this job.

**Pattern that helps you:** real deploy stories, tapeout control, no Python/Tcl flex, no ChipAgents, no metastability trap, 0-delay vs SDF, first-X truncate, isolation-on-wrong-element.

**Pattern that costs you:** two-part questions — you answer the first half and skip **what you do**, **UNR**, **first X**, **ownership stretch**. Checklists need a locked **order** (clock first).

**Oral habit (user noted: not reading the whole question).** Live is not safer. Pause one beat. Restate both asks, then answer both. “Two things: first X, then what I’d do.” If you only said one, add “and the second part…” before you stop.

Skipped: your 4 questions + close. Still rehearse those 2 minutes.

## Questions to Doug (user’s four)

Spoken versions. No relocation, no final offer.

**1. Success 6–12 months** (keep)
> What does success look like in the first 6–12 months for this CAD role — on the team, not just in the JD?

Listen: named flows/DV partners vs vague “ramp and help.” Follow-up: interrupt support vs project work.

**2. Backfill vs new seat** (keep — smart). Don’t sound like “are you desperate.”
> Is this a backfill or a new seat? I ask because it changes what the first year looks like — inherit and stabilize a flow vs stand something up.

Listen: backfill → whose work, what’s on fire. New → greenfield vs extra capacity. Yellow: “the last person left and things are on fire” with no plan.

**3. Next two rounds** (don’t only say “live coding”)
> For the two deep-dive rounds, what should I emphasize — coding, methodology, or debug scenarios? If there’s coding, is it a shared doc or an IDE, and closer to SV/DV or general scripting?

Listen: format, language, panel vs 1:1. Prep from that — don’t volunteer Python.

**4. Team size** (add sites / how CAD pairs with TPU DV)
> How big is the CAD team, and how is it spread across sites? How do you pair with TPU DV day to day?

Listen: you vs a pod; remote vs SC; standardize across geo (your Intel global-lead story maps here).

## Job-critical slice (user asked)

Only: deploy/standardize · tapeout judgment · X/GLS/debug with DV+CAD. Not the full mock average.

| Slice | Grade | % | Notes |
|--------|--------|-----|--------|
| Deploy / standardize | **B+** (substance **A-**) | **88–90** | MT playbook, POC→600 tests→other IPs/SoC is the job. Telling skipped “I owned it” + DV+CAD + 16c vs 4c. |
| Tapeout judgment | **A-** | **91** | ST stays default; tapeout wins; don’t globally kill checks. Add “controlled” workaround. |
| X / GLS / debug + DV+CAD | **A-** on X/GLS, **B+** if UVM hang counts | **90** X/GLS; **88** with UVM | Top 3, 0-delay vs SDF, first-X window, optimism/pessimism, ISO on wrong element. UVM hang skipped clock. |

**Job-critical combined: A- (~90%).** Stronger than overall B+ (~88%). The overall grade was dragged by unfinished two-part answers, why-Google stretch, UNR, UVM order — not by the CAD job itself.

## Attempt 15 — SVA immediate/concurrent + fail storm (spoken)

**Grade: B.** Pieces are right. Fail-storm hunt is too thin. Cover is slightly mixed with covergroup.

Landed: immediate = active region / like `if`; concurrent implication + **preponed sample / observed evaluate**; assume = env/formal; concurrent is where sampling/reset/X show up.

Fixes:
- Concurrent is **clocked** (`@(posedge clk)`), not only `|->`. `disable iff` reset.
- **Cover** = did this property/sequence occur (coverage), not “count assertion fails.”
- Fail storm first: **`disable iff` missing** (fires through reset), wrong clock, X on sampled signals, vacuous vs real. Then “is the property even legit?”
- CAD: waveform vs **sampled** value (preponed) — looks good in NBA, still fails. Perf if they push.

**~25-sec target:**

> Immediate is like an `if` in the active region. Concurrent is clocked — sample in the preponed region, evaluate later — typically `|->` with `disable iff` reset. Assert must hold. Assume constrains the environment, especially formal. Cover records that a behavior happened.
>
> Fail storm: first reset and `disable iff`, then sampling and X on the sampled signals, then whether the property is even right. I don’t chase every fail — same first-cause idea as X-prop. I care about assertion cost in regression, not writing the spec.

## Attempt 16 — constraints: solver fail vs over-constraint vs UNR (spoken)

**Grade: B.** Solver fail vs “sim runs but coverage hole” is a real split. You **never said UNR**. That’s the third bucket Doug asked for.

Landed: conflict → solver errors, look at the pointed constraint, fix, rerun. Over-constraint → sim doesn’t fail, functional coverage incomplete. `dist` = distribution. `solve before` = dependencies (too vague).

Fixes:
- Three buckets: **solver fail** (no solution) vs **hard-to-hit / over-narrow** (legal, rare or biased) vs **UNR** (impossible in this RTL).
- Solver fail: `randomize()` fails / conflicting constraints → debug the conflict, fix TB. Don’t touch UNR.
- Over-narrow: sim passes, bins missing → relax, `dist`, directed. Not UNR.
- UNR: never legal → exclude or fix model/RTL. Don’t add more random.
- `solve before`: **variable order** so implications solve in the intended direction (solve `a` before `b` when `b` depends on `a`).
- `dist`: weights, not “a constraint.” Slow randomize if probed: profiler, huge `foreach`.

**~25-sec target:**

> If `randomize()` errors on conflicting constraints, that’s a solver fail — no solution. I debug the conflict it points at and fix the TB. That’s not UNR.
>
> If sim runs but coverage is short, it may just be over-narrow or hard-to-hit — legal, just rare or biased. Then I relax, use `dist` for spread, or add directed tests. `solve before` is variable order when one constraint depends on another.
>
> Unreachable is different: it can never happen in this RTL. Don’t throw more random at it — UNR, exclude, or fix the model. Three different problems.

## Attempt 11 — GLS X, two weeks out, people want checks off (spoken)

**Grade: A- on the split. Incomplete on dirty 0-delay and on workaround.**

Landed: **0-delay GLS first**; if that’s clean, it’s timing — setup/hold or bad SDF; **don’t globally kill checks**. Did not say metastability.

Fixes:
- If 0-delay is **dirty**, SDF is the wrong hunt. Functional X: reset, multi-driver, glitch, plus GLS extras (CTS reset/clock, contention, gate pessimism).
- Extra GLS sources to name: timing-check X, **unannotated/wrong SDF**, gate X-pessimism / bus contention, netlist connectivity after CTS.
- First X, not the storm.
- Workaround: not “never.” Not “+no_timing_check on the whole run.” Bound **that** check/path, document, keep 0-delay green, **you own** the STA/fix before next drop.

**~30-sec target:**

> First split: is zero-delay GLS clean? I want that data in the flow before SDF GLS. If zero-delay is dirty, this is functional X — reset, multi-driver, glitchy control, maybe reset/clock after CTS or contention. Don’t chase SDF yet. If zero-delay is clean and SDF GLS is an X storm, it’s timing: setup/hold putting X on Q, or bad/partial SDF. I still chase the first X, not every downstream X.
>
> I do not turn timing checks off globally two weeks from tapeout. If one path is a known pessimistic check burning the line, we can bound that check — documented, limited, zero-delay stays green — and I own the real STA/fix. Tapeout gets a controlled workaround, not a silent new standard.

## Attempt 12 — 0-delay GLS dirty, RTL xprop clean (spoken)

**Grade: B+.** Two instincts are hire-level: **compare xprop mode**, and **don’t rerun past first X**. Don’t treat “pessimism” as the bug list.

Landed: ask optimism vs pessimism; netlist sources (disconnected, wrong cells/config, low power, race); truncate sim to first-X time (20ps not 1000ps).

Fixes:
- First: apples to apples. Was RTL **xprop on**? Same test/seed? Merge **optimistic vs pessimistic**?
- If RTL was optimistic or xprop-off, GLS X may be X that RTL hid — still find the first X.
- If RTL pessimistic xprop was clean, hunt **GLS-only**: floating/disconnected nets, wrong std cell/lib config, reset/clock after CTS, contention, isolation.
- Pessimism is the **propagation style**, not the cause. Race / LP / unconnected / wrong cell are causes.
- First X: rerun a short window with waves on that cone (Verdi / XRCA if the gate flow has it). Don’t dump the whole SoC to the original plusarg end time.

**~30-sec target:**

> First I make the compare fair: was RTL xprop even on, and was it optimistic or pessimistic, same test and seed? If RTL was optimistic or xprop-off, GLS can show X that RTL hid. If RTL pessimistic xprop was clean, I look at GLS-only sources: disconnected or floating nets, wrong std-cell or lib config, reset/clock connectivity after CTS, contention, isolation.
>
> I still want the first X, not the storm. If X shows at 20ps in a 1000ps run, I don’t rerun the whole thing. I rerun to that time — waves on that cone — and trace the source. That’s how you debug a huge netlist without burning TAT.

## Attempt 13 — x-optimism vs pessimism + UPF isolation (spoken)

**Grade: A- on merge. B+ on LP.** Mux framing is right. Isolation-on-the-wrong-element is hire-level. You skipped “what I don’t claim.”

**Merge (lock this):**
- **Pessimism:** control is X → output X even if both data inputs match.
- **Optimism:** control is X → output X only if the data inputs **differ**; if they match, it passes that value and can **hide** an X bug.
- Optimism hides bugs. Pessimism can X-storm / false X. That’s why you ask which merge RTL ran.

**LP:** Isolation first, right cell/boundary. Also: isolation **enable**, clamp value. Off-domain corruption to X is often **expected**. The bug is X **escaping** into the on-domain. Don’t claim UPF architect. Not metastability.

SPA: if you say it, one clause — supply/power-aware setup (domain actually off in sim). Don’t let it replace isolation.

**~20-sec LP:**

> If a domain is off and X is storming the live logic, I first check isolation — is the ISO on the right boundary, is the isolation signal on, is the clamp what we intended. Corruption inside the off domain can be expected. The bug is X getting out. I’m the methodology partner on the sim/UPF flow, not the UPF architect.

## Attempt 14 — off-domain X acceptable vs bug; ISO vs retention (spoken)

**Grade: B on the one-liner (inverted). A- on ISO vs retention.**

Landed: ISO = clamp 0/1 at the boundary when PD off; retention = keep original state while PD is off.

**Wrong as stated:** “X is acceptable when it doesn’t have isolation or SPA.”  
Internal off-domain X is often **expected**. A **boundary** signal **without** ISO is a **bug**, not acceptable. Retention targets going X is also a bug.

**Lock:**
- **Acceptable:** X **inside** the off PD (corruption). ISO is not on every internal flop.
- **Flow bug:** X on the **on-side** / crossing — missing ISO, wrong element, enable off, wrong clamp. Or we expected **retention** and got X.

**ISO vs retention:** ISO protects **neighbors** (clamp at boundary). Retention protects **our state** (save/restore on specified seq). Complementary. Don’t claim UPF architect.

**~20-sec target:**

> X inside an off domain is often expected corruption — that’s acceptable. It’s a flow bug when that X shows up on the live side of the boundary: isolation missing, on the wrong element, enable off, or wrong clamp. It’s also a bug if we expected retention and the flop went X instead of saved state.
>
> Isolation clamps a crossing signal to 0 or 1 per policy so the on-domain doesn’t see corruption. Retention saves specified registers across power-down and restores them. ISO protects neighbors; retention protects our state.
