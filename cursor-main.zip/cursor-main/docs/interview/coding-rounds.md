# Coding in the two deep dives (CAD)

**Ask Doug/Tulika.** Do not assume SWE LeetCode. This DV CAD req is methodology + automation, not TB authorship.

## Does Google give a “ref doc”?

| What people mean | Typical |
|------------------|---------|
| Prep packet before the loop | Recruiter **may** send a high-level topic list (not an API manual). Ask Tulika. |
| Where you write code | Often a **Google Doc** (no autocomplete, no compile). Sometimes an IDE/CoderPad. **Ask.** |
| Language/API cheat sheet in the room | **No.** You may ask the interviewer for syntax. Talk while you write. |

Silicon/CAD loops often put **15–20 min of coding inside** a 45-min tech round, not a separate DSA gauntlet. Some interviewers still drop a generic coding question — don’t be shocked, don’t lead with it.

## What CAD coding looks like (this role)

In order of likelihood for **DV CAD**:

1. **Talk-through debug** — hang, X, mismatch, GLS. Little or no code.
2. **Small SV** — flop `=`/`<=`, simple always, SVA sketch, “what’s wrong with this snippet.”
3. **CAD triage automation** — parse a log, count ERROR by test, top-N messages, one pass, edge cases. Language **when they ask**. Show CAD thinking, not SWE puzzles.
4. **Occasional generic coding** — string/hash/count. Keep it boring and correct.

**Mindset:** CAD triage + SV reasoning. Not “I’m a SWE.” Not a ChipAgents pitch.

**Don’t volunteer Python/Tcl.** If they ask language: *whatever fits the customer flow — happy to write it here.*

## Log-parse shape (if they say “write it”)

- Input: lines with `ERROR` plus `test=` and `msg=`
- Count fails per test; top 5 messages
- Narrate: missing fields, duplicates, huge files (one pass)

Ask Doug (already locked):
> For the two deep-dive rounds, what should I emphasize — coding, methodology, or debug scenarios? If there’s coding, is it a shared doc or an IDE, and closer to SV/DV or general scripting?

## What 2× 1-hour actually is

The four flavors above are **what one interviewer might pick one of**, not a checklist to finish in 60 minutes. Two hours = **two people, two independent yes/no signals** for hiring committee. Doug already skimmed you. Deep dives **grind**.

**Each ~60 min (same skeleton, different owner):**

| Min | Block |
|-----|--------|
| 0–5 | Intro |
| 5–25 | **One** resume story to the bone (MT **or** global fault-grading **or** XRCA/Z01X). Follow-ups: ST vs MT, tool vs user vs limitation, tapeout, DV+CAD |
| 25–50 | **One** meaty piece: debug scenario **or** SV snippet **or** log-parse coding **or** “how would you deploy X at Google” |
| 50–60 | Your questions |

**Likely split (not guaranteed — ask Doug):**

- **Round A — methodology / CAD:** deploy a flow, GLS/X, standardize across DV teams, workaround vs default, first 90 days. Interviewer is CAD or a DV lead who eats tool pain.
- **Round B — technical depth:** SV/UVM/coverage/SVA, X-prop/GLS debug, maybe 15–20 min on a Doc. Interviewer may be more DV-flavored.

Could also be **two of the same shape** with two people (Google likes independent samples). Unlikely: four mini-questions, or a full SWE DSA loop, unless one interviewer is SWE-flavored — still possible as a wildcard.

**Why it won’t all fit in one hour:** they will spend 20 minutes on **one** story you already told Doug. That’s the point. Second hour is a **second human**, not leftover bullets.

