# Doug HM — booked

**Thu Aug 20, 2026, 4:00–4:45pm PDT** · Google Meet + **shared Interview Document** (bookmark Nia’s links; join **both**).

Backup phone on file: +1 279-210-1554 (matches). Join ≤5 min early. Laptop. Headphones. Log out of other Google accounts.

This is the **45-min HM**, not a 1-hour deep dive. Shared doc is standard Google — still **talk first**; possible light SV/notes. Full coding stamina is for later rounds.

## Confirm to Nia (reply all)

```
Hi Nia,

Thank you — I confirm Thursday, August 20, 2026, 4:00–4:45pm PDT. I’ll join Google Meet and the interview document.

The backup number +1 279-210-1554 and sudarshanmankad1@gmail.com are correct.

Looking forward to it.

Thank you,
Sudarshan Mankad
```

Send now. Don’t wait.

## Until Thursday (only these)

**Speak-only (print this):** [`doug-speak-scripts.md`](doug-speak-scripts.md)

1. **70-sec about me** ending on Google (VC Z01X, 9+ years, three highlights).
2. **Why Google:** same muscles, **ownership** is the stretch.
3. **MT STAR 90 sec** + ST stays default + 16-core vs 4-core.
4. **Glance card:** X top 3 + first X; 0-delay vs SDF; `=`/`<=` = race; UVM hang **clock first**; config_db type/name/path/timing.
5. **Four questions** + close.

Restate **both halves** of two-part questions out loud once a day.

Don’t negotiate relocation or $225k base with Doug.

## Day of

- Quiet room, Meet test, doc bookmarked, phone nearby.
- If interviewer is 10 min late → Nia / google-candidate-support@google.com
- After: don’t share questions. Wait for Tulika.

## What Nia’s email actually means (don’t miss)

**This slot:** one 45-min conversation (HM). Not the two deep dives. New invites come later.

**Timezone:** 4:00–4:45 **PDT**. Rancho Cordova is PDT in August — 4pm local. Don’t convert.

**Two links, both required:** Google Meet **and** the Interview Document. Open both while logged into **sudarshanmankad1@gmail.com**. Bookmark the doc now. Test Meet (cam/mic/net) before Thursday.

**#1 failure:** “Log out of all other accounts.” Work/Synopsys Google vs personal Gmail. Join Meet **and** the doc as the Gmail that got Nia’s mail. Calendar invite: check Gmail + Calendar spam for a separate hold on Aug 20 4pm.

**Join window:** ≤**5 min** early (not 3:30). If interviewer absent **10 min** → Nia or `google-candidate-support@google.com`. From **Wed 4pm PDT** (24h before), if Nia is unreachable, that support alias **and cc Nia**.

**Phone:** they may call **+1 279-210-1554** if Meet dies. Charged, not DND, laptop is primary (not phone-only). Headphones.

**Shared doc:** standard. Still a talk HM. They might type a snippet. Your own work only — no blogs, coworkers, **no Cursor/ChatGPT on the call**. Glance card on paper is fine; don’t screen-share the cheatsheet (this GitHub repo is **public**).

**Shadows:** up to **two extra Googlers** on the call for training. Talk to the interviewer. They’re not a panel grilling you.

**Integrity / IP:** don’t paste interview questions into email, LinkedIn, or this **public** repo after.

**Accommodations:** `candidateaccommodations@google.com` only if you need them; not required to reply.

**After:** Tulika/Nia follow up. You don’t chase Doug. Leave Aug 24–28 still for **later** rounds.
