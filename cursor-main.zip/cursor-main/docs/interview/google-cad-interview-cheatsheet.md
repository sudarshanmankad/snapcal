# Google CAD Interview Prep — Full Dump

**Candidate:** Sudarshan Mankad  
**Target role:** Senior Engineer — CAD methodology supporting Design Verification (TPU / AI silicon)  
**Recruiter:** Tulika (screen done — sold on intro; ~15 min)  
**HM:** Doug Letcher (next)  
**Process after HM:** 2× 1-hour deep-dive tech → offer  
**Source chat:** https://cursor.com/agents/bc-019fed00-e692-71d4-a563-1c9888ac2d92  

**How to use:** Copy this file into your `cursor` git repo (e.g. `docs/interview/google-cad-interview-cheatsheet.md`).  

**Prep rules (your preferences):**
- Say **automation**, do **not** volunteer Python/Tcl unless asked
- Main tools: **VCS, Verdi, VC Z01X** (SG FA only if asked)
- Partner with **DV and CAD** (not DFT in intro)
- No “CAD–DV boundary” phrasing
- Schedule tradeoffs = **tapeout / project timeline**
- Metastability ≠ X and ≠ `=`/`<=` races
- ChipAgents: don’t pitch; Google CAD is the priority

---

## 1. Process status

| Stage | Status |
|--------|--------|
| Recruiter (Tulika) | Done — went well; intro alone was enough |
| HM (Doug) | Next — ~45 min; 5–10 min for your questions |
| Deep dives | 2× 1-hour tech if HM goes well |
| Then | Offer |

**Doug 45-min time math (agreed):**
- Intros ~5 min
- Dig on intro/resume ~5–10 min
- Methodology/scenarios ~20–25 min
- Your questions ~5–10 min
- **Full coding on Doug call: unlikely**; save coding stamina for deep dives
- Possible light verbal SV/UVM/tech probes

**Relocation:** Follow up with Tulika by email (draft below). Don’t negotiate relocation with Doug.

---

## 2. JD — Role you interviewed for (DV CAD)

**Title flavor:** Senior Engineer — CAD methodology supporting DV / TPU / AI silicon  

### Minimum qualifications
- BS EE/CS or equivalent practical experience
- 5 years CAD
- Experience with SystemVerilog, hardware design, automation, design verification test

### Preferred qualifications
- MS/PhD EE/CE/CS or related
- Experience planning and deploying new tools and flows to users
- Knowledge of chip design process for design and verification
- Ability to present and explain novel methods to users

### Responsibilities
1. Lead CAD methodology engineers to provide support for chip DV teams; manage and mitigate support issues for tool flows
2. Partner with chip project teams to influence and standardize methodology across functional areas and geography
3. Perform or guide technical evaluations of tools for possible deployment
4. Collaborate across Google to identify opportunities for improved chip design
5. Participate in design reviews; track issue resolution; technical and schedule trade-off discussions

### Comp
- US: $163,000 – $237,000 + 15% bonus target + equity + benefits

### About-the-job note
TPU/DV boilerplate may sound like TB authorship. Bridge: you **enable and harden DV flows** so teams verify correctly and hit tapeout schedule. Responsibilities are the real JD.

---

## 3. JD — Doug’s other opening (RTL Design CAD)

**Title:** Senior CAD Engineer, RTL Design, Silicon, Google Cloud  

### How it differs from DV CAD

| | **DV CAD (your req)** | **RTL Design CAD** |
|--|------------------------|---------------------|
| Who you support | Chip **DV** teams | **RTL Design** teams |
| Flavor | Sim/debug/verification flows | RTL quality / design methodology |
| Min bar | 5 yrs CAD; SV/HW/automation/DV test | **8 yrs** SV/HW/automation/DV test; 5 yrs CAD |
| Preferred | Deploy tools/flows; design **and verification** process | Planning, **coding**, deploying flows; **RTL quality** methodology |
| Your fit | **Best match** | Partial — same CAD muscles, less day-to-day RTL-quality tooling story |

**Talking point if asked:**
> Both are CAD methodology seats on the team; one centers on DV enablement, the other on RTL design enablement. My deepest impact is DV-side simulation, debug, and verification flow deployment. I’m primarily focused on the DV CAD role.

Comp nearly identical (~$163k–$236k + 15% + equity).

---

## 4. Full “About me” (use this)

> I’m a Staff Applications Engineer at Synopsys in functional verification—primarily VCS, Verdi, and VC Z01X—with 9+ years helping tier-1 silicon accounts. I’m the primary technical interface for teams at Intel, NXP, ARM, and Rivian, where I own tool evaluation, POCs, deployment into DV flows, and escalations when simulation or methodology puts schedule at risk.
>
> Day to day I partner with both DV and CAD engineers: integrating simulators and debug flows into their environments, driving automation and adoption of new methodologies, and aligning on capability, risk, and tapeout-timeline tradeoffs.
>
> A few examples: multithreaded simulation at Intel Graphics with about 2× regression turnaround; VCS UNR for coverage closure; worldwide technical lead for Intel’s fault-grading program; an XRCA rollout that cut X-propagation debug cycles by more than 50%; and VC Z01X fault grading at NXP through tapeout on multiple IPs.
>
> What draws me to Google is the vertical integration—building state-of-the-art processors like TPU with a full-stack approach to silicon, systems, and AI. At Synopsys I help customers get to tapeout, but I’m not inside the chip team owning the outcome. In this role I can work directly with DV and CAD, standardize the flows, and actually influence how designs get to silicon. I want to bring that same deploy-and-standardize experience inside Google, supporting TPU and AI silicon DV with durable CAD methodology.

### Shorter cut (~60–70 sec)

> I’m a Staff AE at Synopsys in functional verification—mainly VCS, Verdi, and VC Z01X—with 9+ years as the primary technical interface for tier-1 accounts like Intel, NXP, ARM, and Rivian. I own tool eval, POC, deployment, and escalations, and I partner day to day with both DV and CAD engineers on integration, automation, adoption, and tapeout-timeline tradeoffs.
>
> I’ve deployed multithreaded sim at Intel Graphics for about 2× regression turnaround, led Intel’s global fault-grading methodology, cut X-prop debug over 50% with XRCA, and got VC Z01X through tapeout at NXP.
>
> I’m interested in Google because of the vertical integration and the chance to be closer to state-of-the-art processors like TPU—where I can influence tapeout from inside, not only from the vendor side.

### Your mock spoken version (raw — polish toward the script above)

> I’m a staff application engineer at Synopsys in func verif meth, for past 9+ years I have helped tier 1 account like Intel, arm, nxp , etc with VCS, Verdi and vczoix. I primarily own Eval, poc, deployment in dv flows and escalations if sim or meth fails and risks tape out sched.
>
> Day to day I closely work with DV and CAD engineers on deploying Sim and debug meth, driving adoption and automation, handling escalations and assessing capabilities and risk
>
> For example, deployed multithreaded sim at Intel gfx, improved reg tat by 2x. VCS unr enablement for cov closure, tech lead for Intel gfx for dep and esc, Z01X dep at nxp and global tech head for fault sim prog

**Polish nits:** say **VC Z01X**; smoother sentences; optional XRCA metric in examples.

---

## 5. Why Google / why role / why now

### Why Google (human version — use this)

> What draws me to Google is the vertical integration. You’re designing the silicon, the systems, and the workloads together—especially with TPU and AI—so methodology decisions matter end to end. I want to be part of a company building state-of-the-art processors with that full-stack approach, not only optimizing a tool in isolation. At Synopsys I help customers get to tapeout, but I’m not inside the chip team owning the outcome. Here I can sit closer to the product and directly influence how DV and CAD get designs out.

### Why this role

> This is the right seat for that: supporting DV teams on tool flows, deploying and standardizing methodology, evaluating tools, and being in the room for technical and tapeout-timeline tradeoffs.

### Why now / trajectory (IMPORTANT — don’t say “no big transition”)

> Synopsys has been a great place to build depth, but I’m one step removed from tapeout. Google’s vertical integration is where CAD methodology can influence the whole stack.
>
> A lot of what I do today maps directly: working with DV and CAD, deploying flows, handling escalations, driving adoption. So I don’t see it as starting from zero. What will be different—and harder—is going deep on one product’s priorities, building trust as an internal partner instead of a vendor, and being measured by whether Google’s tapeouts and DV throughput actually improve. That’s the transition I’m signing up for.

**Avoid:** “There isn’t a massive transition / I’m already doing the same thing.”  
**Do say:** “Same muscles, different ownership—and the ownership part is the stretch I want.”

### Other companies / AI tooling

> I’ve had light adjacent conversations. This Google CAD role is the priority because it’s hands-on silicon methodology supporting DV.

---

## 6. STAR stories

### Story A — Intel global fault-grading lead (LEAD WITH THIS)
- **S:** Fault grading / FuSa analysis fragmented across regions and Intel teams  
- **T:** Worldwide Synopsys technical lead — one methodology, clear escalation path  
- **A:** Defined VC Z01X / fault-analysis flows; owned escalations from field AEs globally; coordinated R&D; partnered with Intel DV, CAD, program stakeholders  
- **R:** Single methodology ownership; consistent resolution; trusted advisor across server/core/SoC/Graphics  
- **CAD line:** Standardize across functions/geography; escalation path when tool flows break  

### Story B — Intel Graphics multithreaded simulation (METRIC)
- **S:** Graphics IP regressions too slow; Intel wanted ~2× TAT; setup already light on other opts  
- **T:** Eval/POC MT sim and land in production  
- **A:** Discovery with DV/CAD — design suitable for MT; POC on handful of tests; inefficient design sections and **DPI-C** issues found and fixed; saw 5–8× with 16 cores; qualified full design on ~600-test regression; tool crashes/mismatches escalated and fixed; revalidated as design/TB updated until stable **~2× on 4 cores**  
- **R:** Deployed; now on 3 other IPs and scaling to SoC  
- **CAD line:** Evaluate → integrate → qualify → deploy  

**Follow-ups to have ready:**
- Tool bug vs user/flow vs limitation: reproduce minimal; ST vs MT compare; env/plusargs/DPI; escalate reducible cases; limitations bounded  
- Protect schedule: keep ST green; grow MT slice; quarantine fails; flip default only at stable bar  
- First 2 weeks at Google if DV wants 2× TAT: discovery/baselines week 1; bounded pilot + success/rollback plan week 2  

### Story C — XRCA (novel method + metric)
- X-prop debug cycles cut **>50%** via flow integration + enablement; reference rollout pattern  

### Story D — NXP VC Z01X (tapeout)
- Fault sim with functional tests beyond ATPG; **IPs taped out** on flow; later ARM/Rivian FuSa pattern  

### Story E — VCS UNR
- Automated unreachability for coverage closure; won and deployed; sustained usage  

### Workaround vs “right” methodology

> Tapeout schedule wins the immediate call. Ship a controlled workaround—document it, limit scope, keep the line moving. Don’t drop root cause: file it, land real fix for next drop/project, don’t silently normalize the workaround. Same pattern during MT qualification: quarantine/temp config while crashes were fixed before declaring the flow standard.

---

## 7. Leveling

> Externally I’m Staff Applications Engineer. That means senior technical ownership for major silicon accounts: methodology recommendations, deployments, and the escalation path when DV flows are at risk. I mentor junior AEs and coordinate across FAE, R&D, and customer DV and CAD leads. I’m targeting Senior Engineer here and want to align on how Google levels CAD methodology roles—happy to share scope examples so we match L5 versus higher if the bar fits.

If floated lower: validate Senior scope with HM before locking level.  
Avoid: “Any level is fine.”

---

## 8. Comp

**Posted:** $163k–$237k + ~15% bonus + equity + benefits  

**Your lock (cash-flow, not ego):** **Base $225k is a must. Nothing below.** Posted top is ~$237k, so $225k is upper band, not fantasy. HW L5 median base is closer to ~$210k — Google may try to pay you in **GSU**. You need **paycheck**, not headline TC (Bay rent, Sac subsidy, stop selling stock).

| | Number |
|--|--|
| Floor | **$225k base** |
| Target | **$235k** (band top) |
| Opener | **$250k** if they cap base, make whole in **cash sign-on + GSU** |
| Bonus | ~15% → $225k ≈ **$34k**; $235k ≈ **$35k** |
| Cash at $225k | ~**$259k** before equity |
| Steady TC still | Prefer **~$340k+** (so ~$80–110k/yr GSU on top of $225k) |

**$225k math:** ~$18.8k/mo gross. At ~50% in-hand ≈ **$9.4k/mo**; at current ~45% ≈ **$8.5k/mo**. That’s why base won’t trade 1:1 for stock.

If they offer **$215k + fat GSU**: $10k base gap ≈ **$11.5k/yr** cash with bonus. Only consider if **extra cash sign-on** covers it **and** you still feel the paycheck. Default: **hold $225k**.

> Recruiter: “For the move to work I need base at **$225k or above**, upper half of the posted band, plus meaningful equity. I’m flexible on GSU vs sign-on mix, not on a sub-$225k base.”

**Doug:** still don’t finalize numbers. If he presses: “I’m targeting upper half of the posted band plus equity; happy to do details with the recruiter.”

Don’t invent competing offers. Don’t walk a strong packet in the HM. Walk at **offer** if base < $225k with no cash that actually replaces it.

---


## 9. Email to Tulika (thanks + relocation)


---

## 10. Questions to ask

### Recruiter / Tulika
1. Org / how CAD pairs with TPU DV  
2. Methodology vs day-to-day support split  
3. L5 vs L6 for this req  
4. Loop format: coding language, Doc vs IDE, # rounds  
5. Location / hybrid  
6. Timeline  
7. Relocation (email)  
8. Posted band for this level?  

### Doug (pick 4–5)
1. What does success look like in the first 6–12 months on your CAD team?  
2. Biggest DV tool-flow or methodology pain right now?  
3. Split between interrupt-driven support vs project work to improve flows?  
4. How do you partner with DV leads vs central CAD vs tool vendors?  
5. For the two deep-dive rounds, what should I emphasize—coding, methodology, or debug scenarios?  
6. How is the team staffed across sites; how do you standardize?  
7. What separates a strong Senior CAD hire from a good one on this team?  
8. (If relevant) How overlapping are the DV CAD vs RTL Design CAD seats?  

---

## 11. JD → you mapping

| JD ask | You |
|--------|-----|
| 5+ yrs CAD | 9+ yrs EDA methodology, flow integration, deployment |
| SV / HW / automation / DV test | SV sim/debug/coverage/FuSa; automation; DV+CAD partner |
| Support DV; mitigate tool-flow issues | Tier-1 escalation owner |
| Standardize across functions/geo | Intel global fault-grading lead |
| Eval tools for deployment | MT sim, UNR, Z01X, XRCA — POC → prod |
| Design reviews / schedule tradeoffs | DV/CAD/program on tapeout-critical calls |
| MS preferred | M.Tech VLSI |
| Present novel methods | XRCA; SNUG paper/poster with Intel |

**UVM honesty:**
> Strong on UVM/SVA/coverage as methodology and debug partner. Deepest reps: sim/debug methodology, flow integration, automation, deployment—not day-to-day TB authorship.

---

## 12. Technical talk tracks (Doug)

### X-propagation
**Top 3 (your frame):** missing/incomplete reset; multi-driver; glitchy/transitional conditional/control signals.  
Also: low-power off domains; exposed races.  
**Approach:** hypothesis → debug; XRCA to find first X / root cause, not every downstream X.  
**Don’t call common X “metastability.”**

### `=` vs `<=` in clocked logic
**Wrong:** metastability.  
**Right:** blocking `=` updates immediately in active region → other processes may see old or new value depending on order → **simulation race**. `<=` schedules NBA region so flops update together after sampling pre-clock values. Catch via review/lint/order-dependent debug.

### Metastability (only if asked)
Hardware CDC/async sampling risk; synchronizers / MTBF. Separate from most RTL X debug and from `=`/`<=` races. RTL sim usually does not truly model metastable voltages as X.

### UVM hang triage
Clock alive? → phase? → objections (who hasn’t dropped; objection trace)? → TB wait/seq handshake/`item_done`? → DUT deadlock? → tool/flow last.  
Know: drain, phase timeout, heartbeat, forever loops in monitor/scoreboard.

### uvm_config_db
Pass config/VIFs down hierarchy. Failures: wrong **type + name + path + timing** (set after build). Debug: topology print, get status, config tracing.

### Coverage / UNR
Hard-to-hit = legal but rare → directed/constraints.  
Unreachable = can never hit → exclude/fix model/RTL; don’t thrash stimulus.  
Examples of unreachable: impossible branch from parameters; dead else/default given proven encoding; contradictory cover bins; FSM arc that can’t occur.

### SVA
Immediate vs concurrent; assert / assume / cover. CAD cares about fail storms, sampling/reset/X, assertion perf.

### Constraints
Solver fail / over-constraint / bias / slow randomize / solve-before. Separate constraint issues from unreachable design.

### Low power (UPF/NLP)
Power domains, isolation, retention; sim corruption → X when domain off; missing isolation → X storms. You’re methodology partner, not UPF architect.

### GLS / SDF
Gate-level with timing; X from timing violations; late-stage, slower.

### FuSa / Z01X
Fault grading with functional tests beyond ATPG; NXP tapeout; Intel global lead.

### RAS
One honest line only if probed — don’t overclaim.

### Agentic / Verdi MCP debug
Piloted/deployed novel debug methodology with users. No ChipAgents pitch.

### If asked automation language
> Whatever fits the customer flow—scripting and flow integration. Happy to go deeper in technical rounds.

---

## 13. UVM debug pocket card

**Hang:** clock → phase → objections → TB wait/seq → DUT deadlock → tool  
**Config:** type + name + path + before build  
**Stimulus dead:** seq started? active agent? item_done?  
**Coverage:** hard-to-hit vs unreachable  
**SV:** races, X sources, NBA for flops  

**Positioning:**
> I don’t write UVM environments every day, but I debug them constantly with DV—hangs, config/VIF bring-up, stimulus stalls, and coverage closure. I separate TB issues, DUT deadlock, methodology gaps, and real tool problems quickly.

### UVM drills (60–90 sec each)
1. Sim hangs at end of test  
2. config_db VIF get fails  
3. Driver never sees items  
4. Sequence starts but no bus activity  
5. Scoreboard empty  
6. Phase timeout in main  
7. Objection never drops after error  
8. Pass one seed, hang another  
9. Coverage 95% with “impossible” bins  
10. After sim upgrade: same seed, new mismatches  

---

## 14. Resume technology checklist (no stone unturned)

### A — must be cold
- [ ] VCS  
- [ ] Verdi  
- [ ] VC Z01X  
- [ ] SystemVerilog / Verilog  
- [ ] UVM (hang, config_db, seq stall)  
- [ ] X-propagation  
- [ ] Code & functional coverage  
- [ ] Constrained-random  
- [ ] Automation (no language flex)  
- [ ] MT sim story  
- [ ] UNR  
- [ ] XRCA  
- [ ] Eval / POC / deploy / escalations  

### B — ready if probed
- [ ] SVA  
- [ ] UPF/NLP  
- [ ] GLS/SDF  
- [ ] FuSa / ISO 26262 / fault sim  
- [ ] RAS (honest)  
- [ ] Questa/ModelSim one-liner  
- [ ] DPI-C  

### C/D — don’t blank / control narrative
- [ ] Spec-to-testplan  
- [ ] Agentic debug (careful)  
- [ ] C/C++ / Tcl / Python only if asked  

**Pattern per tech:** (1) what it is (2) when it breaks / CAD angle (3) your example  

---

## 15. Mock grades so far (Doug)

| Topic | Grade | Fix |
|--------|--------|-----|
| About-me spine | Good | Smooth; VC Z01X |
| MT sim story | Strong | Open goal/end; DPI-C; DV+CAD |
| Why Google | Good ideas | Ownership transition line |
| Workaround philosophy | Right | Add short example |
| `=`/`<=` | Almost | Race, not metastability |
| X-prop | Strong | Keep top 3 |
| UVM hang | Strong | Add objection trace/phase/clock |
| config_db | Use model | type+name+path+timing |
| Coverage/UNR | Strong | 2 unreachable examples ready |

**Overall for CAD HM:** Lean strong / credible hire if SV wording and trajectory line stay clean. Not a pure UVM-author bar.

---

## 16. Prep time guidance

| Mode | Focused hours |
|------|----------------|
| Doug thorough (talk, no stone unturned) | ~10–12 |
| + coding for 2 deep dives | +6–10 → ~16–22 total |

**Doug primary:** stories + methodology scenarios + resume tech talk  
**Defer heavy blank-doc coding** until after Doug / format confirmed  

**Compressed sessions:**
- Session A (~2 hr): about-me, MT story, why Google, `=`/`<=`, X-prop, workaround example  
- Session B (~2 hr): UVM hang, config_db, coverage, SVA/constraints/LP one-liners, optional mock  

---

## 17. Coding later (deep dives — not Doug focus)

Likely flavors if coding appears: blank shared doc; log parse/count/top-N; small SV snippet; talk-through first.  

Example approach (language only when asked):
- Parse ERROR lines for test= and msg=
- Counters for failures per test and top 5 messages
- One pass; narrate edge cases  

**Mindset:** Show CAD triage automation and SV reasoning — not “I’m a SWE.”

---

## 18. Do / don’t

**Do**
- JD verbs: support DV, mitigate tool flows, standardize, eval/deploy, tapeout tradeoffs  
- DV + CAD partnership  
- VCS, Verdi, VC Z01X  
- Metrics: ~2× TAT, >50% X-prop debug, tapeout, global lead  
- Ask Doug about deep-dive format  

**Don’t**
- Python/Tcl flex unsolicited  
- DFT identity in intro  
- ChipAgents pitch  
- Metastability for races/X  
- “No big transition”  
- Undersell as ticket-only support  
- Trash Synopsys  
- Negotiate final offer/relocation with Doug  

**Close:**
> This maps closely to what I do with DV and CAD at tier-1 accounts. I’m interested in continuing to the deeper technical rounds if you want to move forward.

---

## 19. Facts card

- Staff AE (path AE2 2016 → Senior AE 2020 → Senior AE2 2023 → Staff 2024)  
- Synopsys Oct 2016 – Present — Functional Verification / Simulation & Debug  
- Accounts: Intel (server/core/SoC incl. Titan Lake, Nova Lake; Graphics primary technical lead), NXP, ARM, Rivian, Microsoft  
- Education: M.Tech VLSI; B.E. EEE; PG Diploma ASIC Design & Verification  
- Contact: +1-279-210-1554 | sudarshanmankad1@gmail.com  
- Pubs: SNUG SV 2026 paper with Intel; 2024 poster with Intel  

---

## 20. During-call glance card (Doug)

**Spine:** Staff AE · VCS/Verdi/Z01X · tier-1 · DV+CAD · deploy/automate/escalate · Google vertical integration / influence tapeout  

**Best story:** MT sim deploy **or** global fault-grading lead  

**Best metrics:** ~2× TAT · >50% X-prop · Z01X tapeout  

**Tech traps:** race not meta · X top 3 · hang triage · config_db · hard-to-hit vs unreachable  

**Ask:** success 6–12 mo · biggest pain · support vs projects · deep-dive format · Senior bar  

**Close:** Ready for deep dives  

---

## 21. Import notes for git repo

Suggested path in your `cursor` repo:
```text
docs/interview/google-cad-interview-cheatsheet.md
```
