# X-prop + GLS pocket (Doug)

DV stress: late, slow, X storms, tapeout. You are CAD: flow, debug method, schedule — not the person who wrote the netlist.

**Never:** metastability as the default X answer. Setup/hold X in GLS is a **timing-check model**, not a CDC lecture unless he asks.

## RTL X vs GLS X

| | RTL X-prop | GLS (+ SDF) |
|--|------------|-------------|
| When | Daily sim | Late, slow, tapeout-critical |
| Top sources | Reset, multi-driver, glitchy control | Those **plus** timing-check X, SDF holes, gate X-pessimism, contention, reset/CTS connectivity |
| First move | First X (XRCA), not the storm | First X **and** “is this a timing violation or a functional X?” |
| CAD job | Enable xprop, debug method, don’t normalize X | Zero-delay vs SDF, checks on/off, TAT, when GLS is required |

## Spoken top 3 (RTL) — already locked

Missing/incomplete flop reset · multi-driver · glitchy/transitional control.

**Also:** off domains (isolation), races.

## GLS add-ons (say these)

1. **Timing-check X** — setup/hold fail with SDF → Q goes X. Correlate waveform + SDF/STA path. Don’t blindly turn checks off.
2. **SDF / annotation** — unannotated or wrong corner; delays don’t match STA.
3. **Gate X behavior** — UDP pessimism, mux/case, bus contention, tri-state, don’t-cares that RTL never showed.
4. **Netlist connectivity** — reset/clock after CTS not what RTL assumed.

## Debug order (GLS hang-in-X)

1. Is this **zero-delay GLS** or **SDF timing GLS**? Different problem.
2. Fair compare: was RTL **xprop on**? Optimistic vs pessimistic merge? Same test/seed?
3. Find the **first X** (Verdi / XRCA if the flow has it) — not every downstream X. If X at 20ps, don’t rerun to 1000ps; short window + dump that cone.
4. Classify: functional (reset/driver/control) vs **netlist** (floating, wrong cell, CTS reset/clock, contention, isolation) vs **timing-check** vs **annotation**.
5. Tapeout: controlled workaround (bound X, keep checks on where they still matter), **you own** the real fix.

**X-optimism vs X-pessimism (one line):** optimism can hide X in RTL; pessimism can X-storm. Ask which merge you ran before you blame the netlist.

Mux picture: **pessimism** — select X → Y is X even if both data inputs match. **Optimism** — select X → Y is X only if data inputs differ; if they match, it passes that value (hides the X).

**UPF:** Off-domain X inside the domain can be expected corruption. Bug is X on the **on-side** → isolation cell, enable, clamp, right boundary. You are not the UPF architect.

**ISO vs retention:** Isolation clamps a **boundary** signal (0/1) so neighbors don’t see X. Retention **save/restores** specified flops across power-down. Complementary. A boundary net without ISO is a bug; an internal off-domain X is often not.

## UNR vs X

Don’t mix. UNR = coverage unreachable. X-prop = unknown values corrupting sim. Related only if X kills coverage.

## 25-sec GLS open (if he says “GLS X”)

> RTL X-prop I start with reset, multi-driver, glitchy control, and I chase the first X — XRCA, not the storm. GLS is later and slower. There I also ask: is this a functional X or a timing-check X from SDF? Setup/hold can put X on Q. That’s a timing model, not metastability unless we’re in CDC. CAD job is the flow — zero-delay vs SDF, checks, TAT — and a debug method that doesn’t burn the tapeout regression.
