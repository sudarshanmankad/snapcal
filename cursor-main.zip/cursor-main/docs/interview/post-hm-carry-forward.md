# After HM — carry into deep dives

Don’t paste interview questions here (this GitHub repo is public).

**Meta:** Google CAD HM is technical. The two deep dives will be the same shape. Bring **pain first**, **success metrics before POC**, **don’t flip default**.

**Who:** This 45-min was **not Doug**. Another Googler. Nia never named the HM. Treat it as a **technical interviewer**, not the HM chat we drilled.

**ChipAgents vs this:** Different bar. Google CAD is grind-technical (pain, coverage semantics, search, adoption). Don’t use ChipAgents as the calibration.

**HM scoring (updated after bisect + adoption clarifications):**

| Piece | Grade | Why |
|--------|--------|-----|
| Sim vs synth/DFT code | **B** | “Make them the same” first; Intel sim-vs-DFT example saved it |
| Tool A→B | **B** | POC mechanics good; pain/success criteria late; coverage as raw scores |
| Unknown-n search | **A-** | Said **binary search** first; found a window when he took `n` away. Missed **double then bisect** |
| Adoption | **B+** | Trust → POC on **their** designs. Drifted into 50% workarounds |
| **HM overall** | **B+ (~88–90%)** | Hire conversation. Not a bounce. Packet does **not** hang on the search question. |

**If they ask “do you code / algorithms?”** Don’t say only Verilog/SV. He meant software: scripts, data, search.

> I write automation and SV. I’m not a SWE, but I can code — parsing logs, flow glue, and things like binary search on a failing range. Language whatever the flow uses; I can do it in a doc.

Prep: one log-parse in a Google Doc + binary search / maps / top-N. Don’t volunteer Python until they ask **which** language. When they ask *whether* you code, don’t shrink to HDL.
1. What’s the pain, for whom?
2. What does “done” look like (numbers)?
3. Parallel path, golden stays production.
4. Pilot → qualify → then default.
5. Controlled workaround + you own the real fix.

**Adoption after a burned release:** Trust first. Trust comes from a **POC on their designs**, not a vendor slide. Don’t flip default. Pilot, then expand. Don’t lead with “I wouldn’t have shipped it” as the whole answer — the bad version already shipped. Don’t sell “workaround 50% to spare R&D” as the adoption plan.

**Efficiency questions:** if the **end is unknown**, binary search needs a fail bound first: **double** the step (1, 2, 4, 8…) until a fail, then **bisect** in that window. Stepping +5 is the right idea; doubling is the log N version.

**Coverage across tools:** don’t treat raw scores as apples-to-apples. Define the **intent** (testplan / bins / hierarchy). Tool DBs often don’t match.

**Sim vs synth/DFT code:** they **will** differ on purpose (models, pragmas, DFT). Manage with policy, LEC, lint, owners — not “ideally identical.”
