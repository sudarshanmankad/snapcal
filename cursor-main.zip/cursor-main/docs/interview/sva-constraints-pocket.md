# SVA + constraints pocket (Doug)

You are CAD: debug, perf, sampling, don’t write the TB every day.

**Don’t:** volunteer Python/Tcl. Don’t mix UNR (coverage unreachable) with solver fail. Don’t call assertion X “metastability.”

## SVA — 20 sec

> Immediate asserts fire in the active region like an `if` — good for TB/protocol checks in tasks. Concurrent asserts sample on a clock, `disable iff` reset. Assert = must hold. Assume = constrain the env (formal especially). Cover = did this happen. CAD cares about fail storms, sampling/reset/X, and assertion perf — not authoring the spec.

**CAD hunts**
- Fail storm: missing `disable iff`, fires every cycle, vacuous pass vs real fail
- Sampling: wrong clock/edge; `#0` vs NBA; sampled value vs current
- Reset/X: assertion sees X and fails; same first-X discipline
- Perf: too many concurrent asserts in regression; compile/runtime; disable in GLS if that’s the flow

## Constraints — 20 sec

> If `randomize()` fails, I treat it as over-constraint or conflict — not as unreachable RTL. Hard-to-hit coverage is still legal; a solver fail is the stimulus engine saying no solution. CAD: constraint debug, `solve before` / `dist` bias, slow randomize. Don’t thrash the design.

**CAD hunts**
- Fail / over-constraint: conflicting `inside` / implications; order vs `solve before`
- Bias: `dist` too tight; legal but never hits a bin (that’s still hard-to-hit, not UNR)
- Slow randomize: huge space, `foreach`, nested; profiler; don’t “fix” with UNR
- Separate: **solver fail** vs **unreachable cover** vs **X killing coverage**
