# Continue here

Primary working file: [`docs/interview/google-cad-interview-cheatsheet.md`](docs/interview/google-cad-interview-cheatsheet.md)

## Next

1. **Thu Aug 20 45-min was not Doug.** Another Googler; technical. Notes: [`docs/interview/post-hm-carry-forward.md`](docs/interview/post-hm-carry-forward.md). Wait for Tulika/Nia: who it was, and whether **Doug** is still a separate conversation.
2. **Comp:** base **$225k floor** — recruiter/offer only.
3. **Tulika** — thanks + relocation when the loop continues.

## Comp lock

**Base $225k is a must** for Bay cash-flow. Target $235k. Recruiter only — not Doug.
