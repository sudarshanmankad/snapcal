# Th — Bay Area move and Google offer

- Agent: [bc-019ffdce-d35a-7bea-af8c-ee0149dbaa7a](https://cursor.com/agents/bc-019ffdce-d35a-7bea-af8c-ee0149dbaa7a)
- Topic: Rancho Cordova vs Bay Area, Google Santa Clara (Senior DV CAD / L5), housing, negotiation
- Status: Plan agreed; interviews not done; housing search deferred until an offer

## Constraints (as stated in the chat)

- Own home in Rancho Cordova; **not selling**; rent it (~$3,200 max vs ~$3,600 mortgage → ~$500–1,000/mo subsidy)
- Wife learning to drive; 2.5-year-old; possible second child; **$1,000/mo** family support
- Current job remote; few Sac options. Google SC: prefer **within 50 miles**, **3 days onsite** (maybe 4–5), **$99/night** stay
- Unvested RSUs at current job ~**$80k**. Another offer in hand (leverage). Confirm whether current TC is **$163k** or **$190k**

## Agreed plan

1. Pursue Google SC if the package clears the bar
2. Rent Sac; year-1 Bay rent **$2.8–3.2k** (cap ~$3.5k). Search: **Milpitas → N. San Jose / Santa Clara edges → Fremont/Newark**
3. Do **not** buy Tracy first. Skip Santa Cruz. Morgan Hill is not year-1. Dublin/Livermore buy only later if onsite stays ≤3 days
4. Google childcare is backup care (~20 days/year), not daycare. Budget **~$2–3k/mo** daycare
5. Year 1: insurance on, **401k to match only**, **min ESPP**; stop selling stock to live
6. Optional 30–60 day start ramp: 2 consecutive onsite days + $99 lodging, then local 3-day
7. Sell bulky/dangerous workshop tools; don’t rebuild the garage shop in year 1

## Offer bar

| Piece | Target |
|---|---|
| Base | **$235k** (opener $250k; floor ~$220k with strong cash) |
| Make-whole | **~$80k** cash and/or fast-vest equity |
| TC | Prefer **~$340k+**; **$325–335k** OK if base + sign-on are strong |
| Walk | Base **~$200k** + weak cash, or steady TC under **~$300–310k** |

Sac **$190k ≈ Bay $280k** general COL (does **not** include extra daycare). +20% ≈ **$336–340k**.

## Negotiation script

> I’m excited about the role. To make the move work, I need to address ~$80k in unvested equity I’d forfeit, plus relocation. I’m targeting **$235k base**, and a **sign-on/make-whole around $80k** (cash and/or near-term equity). I also have another offer, so I’m looking for a package that makes the transition clean.

Relocation ramp:

> I’m relocating near SC. To finish rental, daycare, and the move with a toddler, can I have **up to 60 days** with **2 consecutive onsite days** and overnight stays, then full **3-day** local hybrid? I’ll share housing progress along the way.

## Last open thread

Cadence friend pay claims: **~$250k TC** most believable; **$250k base** least believable; do not use him as the comp compass. Conversation ended there.

## Next

- Interviews first (see [scheduler email](../bc-31c4bf00-10f3-469e-88d4-55469c1f3a0a/SUMMARY.md))
- Confirm current TC and competing offer
- Recruiter questions still unasked: 50-mile hard vs soft; relocation $; $99 transition-only?; consecutive onsite days; GSU 4-year grant; backup-care + DCFSA
