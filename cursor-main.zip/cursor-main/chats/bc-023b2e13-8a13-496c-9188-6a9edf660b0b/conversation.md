## User

my company does a survey annually and this time around company is not doing well, as in, people don't believe they want to stay with them, they don't believe in companies business goals, less trust in the company. My manager asked me one on one what are the things I find are not good. He added the first pointer, I gave the rest. 

The growth is slow (promotion, raise, bonus , sport bonus, equity )
Stock price is going down v/s everyone else in industry (hardware) and competition doing better, why?
Achievements are no recognized and management was not even aware of some stuff (ZOIX – NXP etc…)
Anything non VCS and Verdi, no body knows or cares
Need support on ideas, finding right channels to make it happen.
Need environment to innovate and support with manager
Constant mode of layoff and re-org and re-structure is not good for overall organization
More team activities like off site for remote people, there is no occasion where all team members are in the same room.
Shared updates of each years shape survey, what steps we took and how did we measure the success or failure of an initiative.

## Assistant

I’ll turn your notes into clear, professional 1:1 feedback you can share with your manager. First I’ll check the workspace for any related context.

## Assistant

Here is a version you can send or use as talking points. It keeps your points, groups them so they are easier to act on, and stays constructive.

---

**Subject:** Follow-up: what I see behind the SHAPE results

Thanks for asking in our 1:1. Below is the same list we covered, written so it is easier to share or act on. Your first point on growth is included; the rest is what I added.

I still want this company to succeed. These are the gaps that, for me, explain why people do not believe in the goals, do not trust leadership as much, and are less sure they want to stay.

### 1. Growth and rewards feel stalled
Compensation and career movement are slow across promotion, raise, bonus, sport bonus, and equity. When the company is asking people to stay committed, the reward system does not match that ask. People compare notes. Slow growth is one of the fastest ways to lose belief that staying is worth it.

**What would help:** A clear, realistic path for this team: what “good” looks like for promo and pay this cycle, and what is actually in your control vs. not.

### 2. The business story is not landing
Stock is down while hardware peers and competitors are doing better. People notice. If we cannot explain why we are underperforming and what will change that, it is hard to believe in the company strategy. “Trust the plan” does not work when the market is saying the opposite and there is no clear counter-story.

**What would help:** An honest explanation, even if it is uncomfortable: where we are losing, why, and what we are doing differently. Silence reads as “leadership does not have an answer.”

### 3. Work outside VCS/Verdi is invisible
If it is not VCS or Verdi, it often feels like nobody knows or cares. Real customer and product work (for example ZOIX / NXP) was not recognized, and in some cases management did not even know it happened. That is not a recognition problem only. It is a visibility and priority problem. People stop going the extra mile on anything that is not the “main” product.

**What would help:**
- A simple way to surface non-core wins to the right managers, not only the people already in that loop
- Explicit credit in reviews, staff meetings, and skip-levels for work that is not VCS/Verdi
- Someone accountable for making sure those achievements are known before review season, not after

### 4. Ideas have no path, and innovation is not supported
I need help turning ideas into action: who to talk to, which forum, how to get air cover. Right now it is on the individual to find the channel. That is exhausting, and most ideas die. I also need an environment where my manager backs experiments instead of only the current roadmap.

**What would help:**
- A known intake path for ideas (who, what format, what decision timeline)
- Manager support to protect a small amount of time for exploration, and to sponsor the idea upward when it is worth it
- A default of “help me try this” rather than “that is not how we do things here”

### 5. Constant layoff / reorg / restructure mode is damaging the org
The organization has been in a near-constant cycle of layoffs, reorgs, and restructures. That is not just a morale issue. It breaks ownership, makes people conservative, and makes every “new direction” feel temporary. You cannot ask people to believe in long-term goals while the org chart and headcount keep resetting.

**What would help:** Fewer structural changes, longer periods of stability, and when a change is necessary, a clear “this is the last move for X period” message with a reason. Continuous churn reads as the company does not know what it is doing.

### 6. Remote team members never share a room
There is no occasion where the whole team is together. For remote people especially, there are almost no team activities or offsites. You cannot build trust, informal problem-solving, or a sense of one team over video only.

**What would help:** At least one offsite a year where everyone is in the same room, plus a few smaller in-person or social touchpoints so remote people are not only on a screen.

### 7. SHAPE results disappear after the survey
We do the survey, hear the scores, and then it goes quiet. There is no shared update of: what we heard, what we chose to do, how we measured whether it worked, and whether it failed. That is a trust killer. If people never see the loop close, they stop believing the survey matters, and next year’s scores will look like this year’s.

**What would help:** A simple, public-to-the-team cadence after each SHAPE cycle:
1. What we heard (top 3–5 themes)
2. What we committed to do (owners, dates)
3. How we will measure success or failure
4. Mid-year and year-end: what actually happened

If we do not measure it, it did not happen.

---

### How I would say this in the room (short version)

If you only have a few minutes:

“Growth is too slow, the stock story vs. peers is unexplained, and a lot of real work never gets seen unless it is VCS or Verdi. I need a path for ideas and backing from my manager to try things. The constant reorg and layoff cycle is hurting trust. Remote people never meet the rest of the team in person. And we never close the loop on SHAPE: what we did, and whether it worked.”

---

### How to keep this from sounding like a dump

Lead with intent: you are giving this because you were asked, and because you want the team and company to be a place people choose to stay.

Do not over-explain ZOIX/NXP. One concrete example is enough: “management was not aware of customer/product work that should have been visible.” If they ask, then tell the story.

On stock and layoffs, stay factual. You are describing what people experience, not accusing your manager of causing it. Your manager cannot fix the stock price in a 1:1. They can carry the message up, ask for a clearer narrative, and change what they control: recognition, idea channels, team gatherings, and closing the SHAPE loop.

A reasonable ask at the end: “Which of these can you act on at team level, and which do you want me to help you take upward?”

---

I did not put this in the repo. This is 1:1 feedback, not something that belongs in git.

If you want a shorter email, a version with less edge, or a version that only covers what your manager can actually change, say which one and I will write it.

## User

I don't want you to rewrite, I am saying this is what happened. Now you tell me how is my manager going to take this feedback? he did say that we will discuss more on these topics going forward. But, it was a jab at him too saying not a lot of good work is being done towards employees

## Assistant

He will not take the whole list as one thing. He will split it, and the split is not in your favor on the parts that were about him.

**He opened with pay and growth on purpose.** That was him putting the problem on the company, and putting himself on your side. Then you kept going into stock, layoffs, reorgs — which he can nod at — and into recognition, idea support, innovation with the manager, team never meeting, and SHAPE with no follow-through. Those last ones are about whether *he* is doing his job for people. He heard that. “We’ll discuss more” was him not fighting you in the room. It is not the same as agreeing you are right about him.

**What he will repeat upward:** slow growth, stock vs peers, layoff/reorg fatigue. Those make him look like he is listening and they do not make him look bad. That is the version of your 1:1 his boss is likely to hear.

**What he will keep for himself:** management did not even know about ZOIX/NXP; anything not VCS/Verdi does not count; you need channels and his support to innovate; no offsite; survey theater. Those are a performance review of him as a people manager. The ZOIX point is the sharpest. You told him he is out of touch with work on his own team. The “support with manager” point was not coded. He will not forget that even if he stayed calm.

**How it likely felt on his side:** you were asked, so you were allowed to answer. A long list after he already conceded pay still lands as a pile-on. In a company that is already doing layoffs, a manager also hears “you are not protecting us” as risk: this person is unhappy, may leave, may say this in the next survey, may not be a safe advocate. He can respect the honesty and still file you as a retention/morale problem. Those two thoughts sit together.

**“We will discuss more going forward” usually means one of three things:**

1. He needs time to figure out what he can actually do, and he will come back with one or two items.
2. He does not want to argue eight topics in one sitting, and the next move is yours.
3. Soft close. Sounds open, changes nothing unless you bring it up again.

You will know which one it is in the next few 1:1s. If he puts a specific item on the agenda — recognition, an offsite, an idea path, a SHAPE close-the-loop — it landed as feedback he can use. If the next meetings are status-only, or he only wants to talk about pay and “the company,” he took the jab, kept the company points, and parked the rest.

**He is unlikely to say you were unfair.** He is more likely to be polite, slightly more careful, and less likely to volunteer you for visible work until he knows whether you are still on his side. Managers who feel accused of not caring for employees often stop going to bat as hard, not because the points were wrong, but because they no longer assume you see them as an ally.

You do not need to walk it back. You were asked. You were also not only describing the company. You told him employees are not being taken care of, and he is part of that. He heard both. What happens next is whether he treats that as a problem to fix with you, or as a problem you are.

## User

did I give an impression saying I am not wanting to stay or hard to retain?

## Assistant

You did not say you want to leave. You also did not say you want to stay. In a 1:1 that existed because the survey said people do not want to stay, that gap does the talking.

**What you actually signaled** is not “I have another offer.” It is “I am unhappy here, and a lot has to change for this to feel worth it.” Managers usually file that as retention risk. Some will also file it as hard to retain. Those are not the same thing, and he may treat them as the same anyway.

**Why it can sound like you might not stay**

You answered “what is not good?” with pay, stock, your work not counting, layoffs, and no trust that the company follows through. That is the same story people tell themselves before they start looking. You did not have to say “I am out.” The topics already sit in the stay-or-go bucket, especially growth, equity, and “management does not even know what I did.”

You also never closed with anything like “I still want to be here” or “help me make this work.” After a long list, silence on that point is easy to hear as: this person is already halfway out.

**Why it can sound like you are hard to retain**

That is the sharper read, and it is more likely than “he is resigning.”

Hard to retain, in a manager’s head, means: many things are wrong, some of them I do not control, and even if I fix my part this person may still be unhappy. Your list mixed company-level pain (stock, RIFs, promo budget) with manager-level pain (recognition, idea support, offsite, survey loop). That breadth is what makes someone look expensive to keep, not the fact that you spoke up.

The jab matters here. “Not much good is being done for employees” plus “I need support from my manager” can be heard as: keeping me will require a different manager, not just a different company policy.

**What cuts the other way**

Asking for channels, innovation support, team time, and a real SHAPE follow-up is not the language of someone who has already quit. People who are done usually stop asking the company to get better. You were still trying to make the job and the team work. A decent manager can hear that as “this person is stayable if we do something.” A defensive one hears only the complaint.

**The practical answer**

You did not give the impression “I do not want to stay.” You gave the impression “I am not sure this is a place I should stay, and I am not being taken care of.” That is enough for him to mentally tag you as a retention risk. Whether he then tries to keep you, or quietly treats you as already disengaged, depends on whether he took the list as help or as a jab. The next 1:1s will show which. If he never comes back to it, assume he heard risk, not a request to help you stay.

## User

I also told him that on a deployment I gave it all, my weekends, my nights, worked really hard for 1.5-2 years to deploy and it hurts to see that I am aware just 600 points which equates to $20. If I did part time work I'd get $20 per hour. A pat on my back would have been really nice for all this.

## Assistant

Yes. This is the part that does it, more than the rest of the list.

The survey points were about the company. This was about you. You told him you already spent 1.5–2 years of nights and weekends, you know exactly what it converted to (600 points, $20), and you have compared that to what you would have made doing something else. That is how people talk when they are deciding whether the job is still worth it. You do not have to say “I want to leave.” He can hear the math.

**What he is likely to take from it**

You feel used. The extra effort was not a gift you are still happy you gave. It is a debt. “It hurts” means it is not over. “A pat on the back would have been really nice” means the company — and he — failed at the cheap part, not only the expensive part.

The $20 vs part-time line is the sentence that sticks. It puts a price on your loyalty and says the company lost. Once a manager hears that, you are no longer only “someone with org feedback.” You are someone who has done the stay-or-go calculation out loud.

**Wanting to leave vs hard to retain**

You still did not say you are going. You said the current deal is humiliating for what you put in. That usually gets tagged as **retention risk**, not as a resignation notice.

It also gets tagged as **hard to retain**, for a different reason: the hole is two years deep. A thanks now can sound too small, too late, or like he is managing your feelings after the fact. He may think, “even if I praise him, he still wants the promo/money I cannot give.” So you can look both easy to keep in theory (you asked for a pat on the back) and hard to keep in practice (you are already this disappointed).

**The other side of it**

This is also the clearest stay signal in the whole conversation, if he is paying attention. People who are done do not ask for a pat on the back. They stop caring whether anyone noticed. You told him what would have mattered, and that you still wanted it from this place.

So the honest read is: you did not say you refuse to stay. You said you already gave more than you got, you know it, and it still bothers you. Most managers hear that as “this person might not keep doing this, and might not stay if nothing changes.” That is the impression. Whether he then tries to recognize you, or writes you off as bitter, is the next tell.

## User

retention risk means difficult to retain? or high demands to retain?

## Assistant

**Retention risk** means “this person might leave.” It is a probability, not a price.

It does not automatically mean you are difficult, high-maintenance, or expensive. It means: if nothing changes, there is a real chance you walk, check out, or say yes when a recruiter calls.

**Hard to retain** is the other thing. That means “keeping them will take a lot.” High demands, many conditions, hard to satisfy. Promo plus money plus recognition plus a different manager plus a stabler company. That is a cost-and-effort judgment.

They get mixed together because managers are lazy with the labels. After your 1:1, a lot of them will stamp **retention risk** and stop thinking. In their head that can slide into “this one will be hard to keep.” That slide is not required by the term. It is just what busy managers do.

For you, the cleaner read is:

- **Retention risk: yes.** You described a broken deal, you priced it, you said it still hurts. That is “might not stay,” not “here is my list of demands.”
- **High demands to retain: not really.** The thing you named as missing was a pat on the back. That is cheap. Pay, stock, and layoffs are real, but you did not say “I stay only if I get X promo and Y cash.”
- **Difficult to retain: only if he decides the hole is too deep.** If he thinks two years of nights and weekends cannot be fixed with praise, he will treat you as hard to keep even though you did not ask for a large package.

So: retention risk ≠ difficult to retain, and ≠ high demands. It means flight risk. The “this person is expensive/difficult” reading is an extra story he may attach. You did not actually put a high ask on the table. You put a warning on the table.

## User

My manager ended up saying we have failed to promote you. It’s a failure on our side

## Assistant

That is him putting the career part on the company, not on you. It is a strong sentence. It is not a promotion.

**What he was doing.** After the deployment story, the $20, and “a pat on the back would have been nice,” he needed a response that did not argue with your hurt. “We failed to promote you” does three things at once: you were good enough, the gap is not your performance, and he is not going to sit there and defend the outcome. That is why it landed as an apology even though he never said sorry.

**“We” / “our side” matters.** That is shared blame: him, skip-level, the promo process, budget, timing. It is real ownership of the result, and it is also not “I personally blocked you” or “I will fix this by date X.” Managers say “we failed” when they agree you were overdue and they cannot, in that meeting, hand you the level.

**What this does to the earlier read.** He did not only hear a jab. He heard someone the org underpaid in career terms. That is closer to “we should have kept this person moving” than “this person is difficult to retain.” You are still a retention risk in his mind — maybe more than before, because he just admitted the company gave you a reason to leave. The difference is the box: **flight risk because we shorted them**, not **high-maintenance person with a long list**.

**What it does not mean.** It does not mean the promo is approved, funded, or scheduled. In a company that is already doing layoffs and reorgs, “we failed to promote you” can be the whole gift: moral recognition instead of the actual promotion. If the next talks are only more sympathy and no packet, timeline, or “here is what is still missing,” then that line was closure, not a plan.

**The tell.** If he is serious, he will come back with something concrete: target level, who has to say yes, what evidence is already enough vs still needed, and when it gets submitted. If he never names those, he meant “you’re right, and I need you to feel heard,” not “we are promoting you.”

You can take the acknowledgment as real. Do not spend it yet. The sentence says the failure was theirs. The next 1:1s say whether they intend to correct it.

## User

Another thing is that my director asked me to get a feedback/testimony on my work on a tool deployment from client. Client sent it but sent it to me directly. When I forwarded these guys said client should have sent it to them directly and they did not forward it to vp and no recognize it. Now client has sent it directly to these two, it’s has been 24 hours and it’s still not forwarded or recognized. I mentioned it to my manager today, he said he saw it and will reapond. But I don’t think they will

## Assistant

The 24 hours is not the story. The first pass is.

They asked you to get the client to say the work was good. The client did. It came to you, which is what happens when the person who did the deployment asks for it. Then they treated the routing as the problem, did not send it up, and did not recognize you. That was not a process mix-up. That was them leaving value on the table rather than let it count in the “wrong” form.

**Why they said “it should have come to us.”** At their level, a client note to the engineer looks like you collected a compliment. A client note to the director looks like a customer speaking to the business. They want the second thing so they can carry it to the VP as their channel, not your forward. Some of that is how promo and visibility actually work. The rest is credit. If they had cared about you getting the win, they would have said “ask them to copy us” **and** still moved it up. They only did the first half.

**“I saw it and will respond” is a smaller promise than the one you want.** Respond usually means reply to the client: thank you, we are glad, we value the partnership. That can happen and you can still get nothing internally. Forwarding to the VP, putting your name on it, and using it as recognition are separate acts. He did not say he would do those.

**Will they sit on it?** Your doubt is reasonable because of the first email, not because a day has passed. A director leaving a client note for 24 hours is normal. Ignoring a clean, direct client testimony after they already refused the forwarded version is a pattern. Possible reasons they delay even now:

- They reply to the client first and treat that as done.
- They hold it until they can frame it as their team’s win, not a fix for your 1:1.
- Forwarding it now, the same day they told you “we failed to promote you,” makes the miss visible to the VP in writing. Some people slow-walk that.

It could still move. The director asked for this testimony. They wanted ammunition. Now it is in the form they demanded. Using it helps them too, not only you. After today’s conversation, this is also the cheapest way for your manager to prove the “we failed you” line was not just talk.

**How you will know.** Not by his tone. By the email trail in the next few days:

- He thanks the client and copies you and the VP, with your work named → it counted.
- He thanks the client, no VP, no you in the story → they took the relationship and left you out again.
- Nothing → your read was right.

Do not wait months and do not chase daily. If it has not gone up in a week, the recognition you were told to fetch is being used as customer hygiene, not as credit for you. That fits the same picture as the $20 and the missed promo: they will admit the failure in a 1:1 before they will spend political capital to correct it in front of a VP.

## User

send a reminder to manager a week later? or send it to both manager and director ? I want to say now it is in the format they wanted, it should be shared with VP.

## Assistant

Send it to your **manager only**, about a **week** after the client emailed them. Do not copy the director on the first reminder.

The director already has the note. Copying both turns a nudge into a written call-out: you sat on this, I am documenting it. That is the same jab pattern as the 1:1, now on email, and it gives them a reason to handle the client and still not put your name in front of the VP.

Also do not write “now it is in the format you wanted.” That is true, and it will make them defend the process instead of forwarding. The point you want is the same: this is the version that can go to the VP, please send it.

**Send this:**

Subject: Client note on the deployment — please share with [VP]

Hi [Manager],

Checking back on the client note that went to you and [Director] last week. Could you please forward it to [VP] and copy me?

That was the reason we asked the client to send it directly. I want it on [VP]’s radar, and I need the thread for my record.

If it helps, I can send you a 3-line forward you can paste.

Thanks,  
[Name]

That is one ask, it assumes he will do it, and it makes “no” visible if he still does not.

If a week after this mail there is still no forward, then bring the director in, still through your manager:

Hi [Manager],  
I have not seen this go to [VP] yet. Do you want me to send [Director] a short draft to forward, or should I wait on you?  
[Name]

Do not email the VP yourself. Do not re-forward the client testimony to all three as if they missed it. They have it. You are asking for the internal step they would not take the first time.
