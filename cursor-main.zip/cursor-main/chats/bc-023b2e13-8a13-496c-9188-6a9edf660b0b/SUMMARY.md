# Organizational health concerns

- Agent: [bc-023b2e13-8a13-496c-9188-6a9edf660b0b](https://cursor.com/agents/bc-023b2e13-8a13-496c-9188-6a9edf660b0b)
- Topic: Workplace coaching after a 1:1 on the annual **SHAPE** survey
- Status: Reminder email drafted; waiting ~1 week after client note reached manager + director

## Situation

Manager asked what was not good. Manager added the first point (slow growth); user added the rest: stock vs hardware peers, unrecognized work (**ZOIX–NXP**; anything not **VCS/Verdi**), no path for ideas, layoff/reorg fatigue, no in-person team time, SHAPE never closed the loop.

User did **not** want a rewrite. Working read:

- Manager will split the list: company issues go upward; recognition / idea-path / ZOIX are a review of him
- User did not say they are leaving. Combined with SHAPE + the $20 / nights-and-weekends story, this files as **retention risk** (might leave), not automatically **hard to retain** (high demands)
- Manager: “we have failed to promote you. It’s a failure on our side.” That is acknowledgment, **not a promotion**. Watch whether the next 1:1 names level, approvers, evidence, and a date
- Client testimony: director asked for it; first send went to the user; they wanted it sent to them directly; still not forwarded to VP. Manager “saw it and will respond” likely means reply to the client, not credit to VP

## Reminder (manager only, ~one week after they received the client note)

Subject: `Client note on the deployment — please share with [VP]`

```
Hi [Manager],

Checking back on the client note that went to you and [Director] last week. Could you please forward it to [VP] and copy me?

That was the reason we asked the client to send it directly. I want it on [VP]’s radar, and I need the thread for my record.

If it helps, I can send you a 3-line forward you can paste.

Thanks,
[Name]
```

Do **not** copy the director on the first reminder. Do **not** write “now it is in the format you wanted.” Do **not** email the VP yourself.

If still no forward a week later:

```
Hi [Manager],
I have not seen this go to [VP] yet. Do you want me to send [Director] a short draft to forward, or should I wait on you?
[Name]
```

## Next

- Send the manager-only reminder if a week has passed
- Watch whether the missed-promo line becomes a real packet
- Related: Google / move planning in [Th](../bc-019ffdce-d35a-7bea-af8c-ee0149dbaa7a/SUMMARY.md)
