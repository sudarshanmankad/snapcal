# Imported Cursor cloud-agent chats

Archive of cloud-agent conversations for `github.com/sudarshanmankad/cursor`, imported 2026-08-16 so work can continue in this repo.

**This GitHub repository is public.** These chats include personal career, compensation, housing, and workplace notes. Make the repo private if that should not be public.

## Requested chat (dump imported)

The live agent `bc-019fed00-e692-71d4-a563-1c9888ac2d92` still cannot be fetched from this repo. The generated Google CAD cheatsheet from that chat was pasted in and saved at [`docs/interview/google-cad-interview-cheatsheet.md`](../docs/interview/google-cad-interview-cheatsheet.md). See [that folder](bc-019fed00-e692-71d4-a563-1c9888ac2d92/README.md).

## Imported from this repo

| Folder | Name | What it is |
|---|---|---|
| [bc-023b2e13-8a13-496c-9188-6a9edf660b0b](bc-023b2e13-8a13-496c-9188-6a9edf660b0b/) | Organizational health concerns | SHAPE 1:1, recognition, client testimony |
| [bc-019ffdce-d35a-7bea-af8c-ee0149dbaa7a](bc-019ffdce-d35a-7bea-af8c-ee0149dbaa7a/) | Th | Google SC / Bay Area move / offer math |
| [bc-31c4bf00-10f3-469e-88d4-55469c1f3a0a](bc-31c4bf00-10f3-469e-88d4-55469c1f3a0a/) | Interview availability scope | Email to Google scheduler Nia |

Each imported folder has:

- `SUMMARY.md` — decisions and next steps
- `conversation.md` — user and assistant text only
- `transcript.json` — full raw transcript
- `metadata.json` — agent id, URL, timestamps

Continue from [CONTINUE.md](../CONTINUE.md).
