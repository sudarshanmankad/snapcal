# Interview availability scope

- Scheduler: **Nia** (with **Tulika Thakur**)
- **BOOKED:** Thu **Aug 20, 2026, 4:00–4:45pm PDT** — 45 min (HM, likely Doug)
- Join **Google Meet + shared Interview Document** (links in Nia’s email)
- Backup phone: +1 279-210-1554 · email: sudarshanmankad1@gmail.com

## Reply (send reply-all)

See [`docs/interview/doug-hm-booked.md`](../../docs/interview/doug-hm-booked.md).

Leave Aug 24–28 still true for **later** rounds; this slot is this week.
