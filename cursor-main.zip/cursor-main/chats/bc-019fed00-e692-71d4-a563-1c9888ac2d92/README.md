# Source chat: `bc-019fed00-e692-71d4-a563-1c9888ac2d92`

The live agent is still not fetchable from this repository. The generated dump from that chat was pasted in and saved at:

[`docs/interview/google-cad-interview-cheatsheet.md`](../../docs/interview/google-cad-interview-cheatsheet.md)

That is the Google CAD interview prep file (HM Doug Letcher, recruiter Tulika, STAR stories, tech tracks).
